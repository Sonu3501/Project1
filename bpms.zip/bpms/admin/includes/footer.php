<!--footer-->
    <div class="footer">
       <p>&copy; 2019 BPMS Admin Panel.</p>
    </div>
        <!--//footer-->